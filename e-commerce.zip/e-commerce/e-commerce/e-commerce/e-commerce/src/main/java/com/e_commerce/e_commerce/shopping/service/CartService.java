package com.e_commerce.e_commerce.shopping.service;

import com.e_commerce.e_commerce.shopping.entity.Cart;
import com.e_commerce.e_commerce.shopping.entity.CartItem;
import com.e_commerce.e_commerce.shopping.repository.CartRepository;
import com.e_commerce.e_commerce.shopping.repository.CartItemRepository;
import com.e_commerce.e_commerce.catalog.entity.Product;
import com.e_commerce.e_commerce.catalog.repository.ProductRepository;
import com.e_commerce.e_commerce.customer.entity.User;
import com.e_commerce.e_commerce.customer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    public Cart getCartByUserId(Long userId) {
        return cartRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Panier non trouvé pour l'utilisateur: " + userId));
    }

    @Transactional
    public Cart addToCart(Long userId, Long productId, int quantity) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé: " + userId));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Produit non trouvé: " + productId));

        Cart cart = cartRepository.findByUserId(userId)
                .orElse(new Cart(user));

        if (cart.getId() == null) {
            cart = cartRepository.save(cart);
        }

        Optional<CartItem> existingItem = cartItemRepository.findByCartIdAndProductId(cart.getId(), productId);

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            int newQuantity = item.getQuantity() + quantity;

            item.setQuantity(newQuantity);
            cartItemRepository.save(item);
        } else {
            CartItem newItem = new CartItem(quantity, product.getPrice(), product);
            newItem.setCart(cart);
            cart.addItem(newItem);
            cartItemRepository.save(newItem);
        }

        return cartRepository.save(cart);
    }

    @Transactional
    public Cart updateQuantity(Long cartItemId, int newQuantity) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Article du panier non trouvé: " + cartItemId));

        if (newQuantity <= 0) {
            Cart cart = item.getCart();
            cart.removeItem(item);
            cartItemRepository.delete(item);
            return cartRepository.save(cart);
        }
        item.setQuantity(newQuantity);
        cartItemRepository.save(item);

        return cartRepository.save(item.getCart());
    }

    @Transactional
    public Cart removeItem(Long cartItemId) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Article du panier non trouvé: " + cartItemId));

        Cart cart = item.getCart();
        cart.removeItem(item);
        cartItemRepository.delete(item);

        return cartRepository.save(cart);
    }

    @Transactional
    public void clearCart(Long userId) {
        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Panier non trouvé pour l'utilisateur: " + userId));

        cart.getItems().clear();
        cartRepository.save(cart);
    }
}