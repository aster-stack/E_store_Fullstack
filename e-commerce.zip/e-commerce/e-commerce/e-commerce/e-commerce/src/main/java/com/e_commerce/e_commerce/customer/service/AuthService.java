package com.e_commerce.e_commerce.customer.service;

import com.e_commerce.e_commerce.customer.entity.Profile;
import com.e_commerce.e_commerce.customer.entity.User;
import com.e_commerce.e_commerce.customer.repository.ProfileRepository;
import com.e_commerce.e_commerce.customer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final ProfileRepository profileRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Register a new user
     */
    public User register(User user) {
        // Check if email already exists
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("Email déjà utilisé");
        }

        // Encode password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Set role (default to CLIENT if not provided, otherwise use the provided role)
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("CLIENT");
        } else {
            user.setRole(user.getRole().toUpperCase());
        }

        // Save user
        User saved = userRepository.save(user);

        // Create empty profile for the user
        Profile profile = new Profile();
        profile.setUser(saved);
        profileRepository.save(profile);

        // Return saved user (without password for security)
        saved.setPassword(null);
        return saved;
    }

    /**
     * Login user and return user data with token
     */
    public Map<String, Object> login(String email, String password) {
        // Find user by email
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        // Verify password
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Mot de passe incorrect");
        }

        // Generate a simple token (in production, use JWT)
        String token = generateToken(user);

        // Prepare response
        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("id", user.getId());
        response.put("firstName", user.getFirstName());
        response.put("lastName", user.getLastName());
        response.put("email", user.getEmail());
        response.put("role", user.getRole());

        // Also include user object for backward compatibility
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("id", user.getId());
        userMap.put("firstName", user.getFirstName());
        userMap.put("lastName", user.getLastName());
        userMap.put("email", user.getEmail());
        userMap.put("role", user.getRole());
        response.put("user", userMap);

        return response;
    }

    /**
     * Generate a simple authentication token
     * In production, replace with proper JWT generation
     */
    private String generateToken(User user) {
        // Simple token generation - in production use JWT
        String token = user.getId() + "_" +
                System.currentTimeMillis() + "_" +
                user.getEmail().hashCode();
        return "Bearer_" + token;
    }
}