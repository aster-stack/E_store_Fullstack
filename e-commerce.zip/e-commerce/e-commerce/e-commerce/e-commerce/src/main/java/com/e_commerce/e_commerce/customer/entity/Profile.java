package com.e_commerce.e_commerce.customer.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "profiles")
public class Profile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String phone;
    private String address;
    private String city;
    private String country;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}