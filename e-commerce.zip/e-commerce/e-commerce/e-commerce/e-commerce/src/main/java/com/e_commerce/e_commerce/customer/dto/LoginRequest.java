package com.e_commerce.e_commerce.customer.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String email;
    private String password;
}