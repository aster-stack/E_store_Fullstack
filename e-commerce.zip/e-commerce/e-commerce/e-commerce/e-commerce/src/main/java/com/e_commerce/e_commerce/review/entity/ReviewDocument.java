package com.e_commerce.e_commerce.review.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "reviews")
public class ReviewDocument {

    @Id
    private String id;
    private Long productId;    // ← Field name must match "productId"
    private Long userId;       // ← Field name must match "userId"
    private String authorName;
    private int rating;
    private String comment;
    private LocalDateTime createdAt;

    // Constructors
    public ReviewDocument() {}

    public ReviewDocument(Long productId, Long userId, String authorName,
                          int rating, String comment) {
        this.productId = productId;
        this.userId = userId;
        this.authorName = authorName;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = LocalDateTime.now();
    }

    // Getters (must exist for stream mapping)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAuthorName() { return authorName; }
    public void setAuthorName(String authorName) { this.authorName = authorName; }

    public int getRating() { return rating; }      // ← Critical for average calculation
    public void setRating(int rating) { this.rating = rating; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}