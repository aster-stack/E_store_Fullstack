package com.e_commerce.e_commerce.inventory.service;

import com.e_commerce.e_commerce.inventory.entity.Inventory;
import com.e_commerce.e_commerce.inventory.repository.InventoryRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InventoryService {

    private final InventoryRepository inventoryRepository;

    public InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    public Inventory getStock(Long productId) {
        return inventoryRepository.findByProductId(productId)
                .orElseThrow(() -> new RuntimeException("Stock not found for product: " + productId));
    }

    public Inventory addStock(Long productId, int quantity) {
        if (inventoryRepository.findByProductId(productId).isPresent()) {
            throw new RuntimeException("Stock already exists");
        }
        Inventory inventory = new Inventory();
        inventory.setProductId(productId);
        inventory.setQuantity(quantity);
        return inventoryRepository.save(inventory);
    }

    public Inventory updateStock(Long productId, int quantity) {
        Optional<Inventory> existing = inventoryRepository.findByProductId(productId);
        if (existing.isPresent()) {
            Inventory inventory = existing.get();
            inventory.setQuantity(quantity);
            return inventoryRepository.save(inventory);
        } else {
            Inventory inventory = new Inventory();
            inventory.setProductId(productId);
            inventory.setQuantity(quantity);
            return inventoryRepository.save(inventory);
        }
    }

    public void reduceStock(Long productId, int quantity) {
        Optional<Inventory> existing = inventoryRepository.findByProductId(productId);
        if (existing.isEmpty()) {
            return;
        }
        Inventory inventory = existing.get();
        if (inventory.getQuantity() < quantity) {
            throw new RuntimeException("Not enough stock for product: " + productId);
        }
        inventory.setQuantity(inventory.getQuantity() - quantity);
        inventoryRepository.save(inventory);
    }

    public void deleteStock(Long productId) {
        Inventory inventory = getStock(productId);
        inventoryRepository.delete(inventory);
    }

    public boolean isAvailable(Long productId, int quantity) {
        Optional<Inventory> existing = inventoryRepository.findByProductId(productId);
        if (existing.isEmpty()) {
            return true;
        }
        return existing.get().getQuantity() >= quantity;
    }
}