package com.e_commerce.e_commerce.shopping.entity;

import jakarta.persistence.*;
import com.e_commerce.e_commerce.catalog.entity.Product;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Entity
@Data
@Table(name = "cart_items")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private int quantity;

    @Column(name = "unit_price", nullable = false)
    private double unitPrice;

    @ManyToOne
    @JoinColumn(name = "cart_id", nullable = false)
    @JsonIgnore  // Prevents circular serialization: CartItem → Cart → CartItem → ...
    private Cart cart;

    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    public CartItem() {}

    public CartItem(int quantity, double unitPrice, Product product) {
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.product = product;
    }

    public double getSubtotal() {
        return this.unitPrice * this.quantity;
    }
}