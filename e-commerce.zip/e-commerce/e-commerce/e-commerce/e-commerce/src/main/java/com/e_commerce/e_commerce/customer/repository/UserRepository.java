package com.e_commerce.e_commerce.customer.repository;

import com.e_commerce.e_commerce.customer.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}
