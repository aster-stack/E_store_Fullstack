package com.e_commerce.e_commerce.customer.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;

    @Column(unique = true)
    private String email;

    private String password;
    private String role; // CLIENT or SELLER or ADMIN

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private Profile profile;
}