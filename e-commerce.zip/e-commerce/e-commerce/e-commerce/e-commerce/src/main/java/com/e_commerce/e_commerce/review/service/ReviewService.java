package com.e_commerce.e_commerce.review.service;


import com.e_commerce.e_commerce.review.entity.ReviewDocument;
import com.e_commerce.e_commerce.review.repository.ProductReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReviewService {

    @Autowired
    private ProductReviewRepository reviewRepository;

    public ReviewDocument addReview(ReviewDocument review) {
        return reviewRepository.save(review);
    }

    public List<ReviewDocument> getReviewsByProduct(Long productId) {
        return reviewRepository.findByProductId(productId);
    }

    public List<ReviewDocument> getReviewsByUser(Long userId) {
        return reviewRepository.findByUserId(userId);
    }

    public double getAverageRating(Long productId) {
        List<ReviewDocument> reviews = getReviewsByProduct(productId);
        return reviews.stream()
                .mapToInt(ReviewDocument::getRating)
                .average()
                .orElse(0.0);
    }
}