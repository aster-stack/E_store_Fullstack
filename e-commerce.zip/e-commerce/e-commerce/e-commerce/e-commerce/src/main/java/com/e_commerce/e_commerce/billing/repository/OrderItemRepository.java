package com.e_commerce.e_commerce.billing.repository;

import com.e_commerce.e_commerce.billing.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {}