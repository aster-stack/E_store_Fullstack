package com.e_commerce.e_commerce.config;

import com.e_commerce.e_commerce.catalog.entity.Category;
import com.e_commerce.e_commerce.catalog.entity.Product;
import com.e_commerce.e_commerce.catalog.repository.CategoryRepository;
import com.e_commerce.e_commerce.catalog.repository.ProductRepository;
import com.e_commerce.e_commerce.inventory.entity.Inventory;
import com.e_commerce.e_commerce.inventory.repository.InventoryRepository;
import com.e_commerce.e_commerce.customer.entity.User;
import com.e_commerce.e_commerce.customer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final InventoryRepository inventoryRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {

        if (categoryRepository.count() > 0) return;

        // Categories
        Category electronics = new Category();
        electronics.setName("Électronique");
        electronics.setDescription("Téléphones, ordinateurs, accessoires");
        categoryRepository.save(electronics);

        Category books = new Category();
        books.setName("Livres");
        books.setDescription("Romans, manuels, bandes dessinées");
        categoryRepository.save(books);

        Category sport = new Category();
        sport.setName("Sport");
        sport.setDescription("Équipements et vêtements de sport");
        categoryRepository.save(sport);

        // Products
        Product laptop = new Product();
        laptop.setName("Laptop Pro 15");
        laptop.setDescription("Ordinateur portable haute performance, 16GB RAM, 512GB SSD");
        laptop.setPrice(8999.99);
        laptop.setImageUrl("https://via.placeholder.com/300x200?text=Laptop");
        laptop.setCategory(electronics);
        productRepository.save(laptop);

        Product phone = new Product();
        phone.setName("Smartphone X12");
        phone.setDescription("Écran AMOLED 6.7\", batterie 5000mAh, triple caméra");
        phone.setPrice(3499.99);
        phone.setImageUrl("https://via.placeholder.com/300x200?text=Phone");
        phone.setCategory(electronics);
        productRepository.save(phone);

        Product headphones = new Product();
        headphones.setName("Casque Audio Pro");
        headphones.setDescription("Réduction de bruit active, autonomie 30h");
        headphones.setPrice(1299.99);
        headphones.setImageUrl("https://via.placeholder.com/300x200?text=Headphones");
        headphones.setCategory(electronics);
        productRepository.save(headphones);

        Product javaBook = new Product();
        javaBook.setName("Java Spring Boot en pratique");
        javaBook.setDescription("Guide complet du développement Spring Boot 3");
        javaBook.setPrice(249.99);
        javaBook.setImageUrl("https://via.placeholder.com/300x200?text=Book");
        javaBook.setCategory(books);
        productRepository.save(javaBook);

        Product football = new Product();
        football.setName("Ballon de football Pro");
        football.setDescription("Ballon officiel taille 5, qualité match");
        football.setPrice(199.99);
        football.setImageUrl("https://via.placeholder.com/300x200?text=Football");
        football.setCategory(sport);
        productRepository.save(football);

        // Inventory
        addInventory(laptop.getId(), 20);
        addInventory(phone.getId(), 50);
        addInventory(headphones.getId(), 30);
        addInventory(javaBook.getId(), 100);
        addInventory(football.getId(), 75);

        // Demo user
        if (userRepository.count() == 0) {
            User user = new User();
            user.setFirstName("Ahmed");
            user.setLastName("Test");
            user.setEmail("test@estore.com");
            user.setPassword(passwordEncoder.encode("password123"));
            user.setRole("CLIENT");
            userRepository.save(user);
        }

        System.out.println(">>> DataInitializer: données de démonstration chargées !");
    }

    private void addInventory(Long productId, int qty) {
        if (inventoryRepository.findByProductId(productId).isEmpty()) {
            Inventory inv = new Inventory();
            inv.setProductId(productId);
            inv.setQuantity(qty);
            inventoryRepository.save(inv);
        }
    }
}