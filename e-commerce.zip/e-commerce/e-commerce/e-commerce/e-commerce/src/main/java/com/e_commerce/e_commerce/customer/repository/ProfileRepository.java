package com.e_commerce.e_commerce.customer.repository;

import com.e_commerce.e_commerce.customer.entity.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ProfileRepository extends JpaRepository<Profile, Long> {
    Optional<Profile> findByUserId(Long userId);
}