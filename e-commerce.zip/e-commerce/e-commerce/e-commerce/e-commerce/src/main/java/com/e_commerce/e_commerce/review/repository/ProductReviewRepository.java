package com.e_commerce.e_commerce.review.repository;

import com.e_commerce.e_commerce.review.entity.ReviewDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductReviewRepository extends MongoRepository<ReviewDocument, String> {
    List<ReviewDocument> findByProductId(Long productId);
    List<ReviewDocument> findByUserId(Long userId);
}