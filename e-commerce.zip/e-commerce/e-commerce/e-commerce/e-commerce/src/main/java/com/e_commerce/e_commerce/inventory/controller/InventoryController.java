package com.e_commerce.e_commerce.inventory.controller;

import com.e_commerce.e_commerce.inventory.entity.Inventory;
import com.e_commerce.e_commerce.inventory.service.InventoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin("*")
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping("/{productId}")
    public Inventory getStock(@PathVariable Long productId) {
        return inventoryService.getStock(productId);
    }

    @PostMapping("/add")
    public Inventory addStock(@RequestParam Long productId,
                              @RequestParam int quantity) {
        return inventoryService.addStock(productId, quantity);
    }

    @PutMapping("/update")
    public Inventory updateStock(@RequestParam Long productId,
                                 @RequestParam int quantity) {
        return inventoryService.updateStock(productId, quantity);
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<String> deleteStock(@PathVariable Long productId) {
        inventoryService.deleteStock(productId);
        return ResponseEntity.ok("Stock supprimé avec succès !");
    }
}