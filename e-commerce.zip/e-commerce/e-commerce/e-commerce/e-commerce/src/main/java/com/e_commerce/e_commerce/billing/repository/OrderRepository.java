package com.e_commerce.e_commerce.billing.repository;

import com.e_commerce.e_commerce.billing.entity.Order;
import com.e_commerce.e_commerce.customer.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findByUser(User user);

    List<Order> findByStatus(String status);
}