package com.e_commerce.e_commerce.billing.service;

import com.e_commerce.e_commerce.billing.entity.Order;

import java.util.List;

public interface OrderService {

    Order createOrder(Long userId);

    List<Order> getOrdersByUser(Long userId);

    List<Order> getOrdersByStatus(String status);

    Order getOrderById(Long id);

    void deleteOrder(Long orderId);
}