package com.e_commerce.e_commerce.billing.service;

import com.e_commerce.e_commerce.billing.entity.Order;
import com.e_commerce.e_commerce.billing.entity.OrderItem;
import com.e_commerce.e_commerce.billing.repository.OrderRepository;
import com.e_commerce.e_commerce.customer.entity.User;
import com.e_commerce.e_commerce.customer.repository.UserRepository;
import com.e_commerce.e_commerce.exception.InsufficientStockException;
import com.e_commerce.e_commerce.exception.ResourceNotFoundException;
import com.e_commerce.e_commerce.shopping.repository.CartRepository;
import com.e_commerce.e_commerce.inventory.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final CartRepository cartRepository;
    private final InventoryService inventoryService;

    @Override
    public Order createOrder(Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User n'exist pas"));

        var cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart n'exist pas"));

        if (cart.getItems().isEmpty()) {
            throw new ResourceNotFoundException("Le panier est vide");
        }

        Order order = new Order();
        order.setUser(user);

        double total = 0;

        for (var cartItem : cart.getItems()) {

            Long productId = cartItem.getProduct().getId();
            int quantity = cartItem.getQuantity();

            if (!inventoryService.isAvailable(productId, quantity)) {
                throw new InsufficientStockException("Stock insuffisant pour le produit ID: " + productId);
            }

            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(quantity);
            orderItem.setUnitPrice(cartItem.getProduct().getPrice());

            order.addItem(orderItem);
            total += orderItem.getSubtotal();

            inventoryService.reduceStock(productId, quantity);
        }

        order.setTotalAmount(total);
        Order saved = orderRepository.save(order);

        cart.getItems().clear();
        cartRepository.save(cart);

        return saved;
    }

    @Override
    public List<Order> getOrdersByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User n'exist pas"));
        return orderRepository.findByUser(user);
    }

    @Override
    public List<Order> getOrdersByStatus(String status) {
        return orderRepository.findByStatus(status);
    }

    @Override
    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order n'exist pas"));
    }

    @Override
    public void deleteOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));
        orderRepository.delete(order);
    }
}