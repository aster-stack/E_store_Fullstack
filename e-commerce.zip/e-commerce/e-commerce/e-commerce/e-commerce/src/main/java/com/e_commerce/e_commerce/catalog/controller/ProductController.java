package com.e_commerce.e_commerce.catalog.controller;

import com.e_commerce.e_commerce.catalog.entity.Product;
import com.e_commerce.e_commerce.catalog.entity.Review;
import com.e_commerce.e_commerce.catalog.service.CatalogService;
import com.e_commerce.e_commerce.inventory.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/catalog")
@CrossOrigin("*")
@RequiredArgsConstructor
public class ProductController {

    private final CatalogService catalogService;
    private final InventoryService inventoryService;

    @GetMapping("/products")
    public List<Product> list(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId) {
        if (keyword != null && !keyword.isBlank()) {
            return catalogService.searchByKeyword(keyword);
        }
        if (categoryId != null) {
            return catalogService.filterByCategory(categoryId);
        }
        return catalogService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public Map<String, Object> details(@PathVariable Long id) {
        Product product = catalogService.getProductById(id);
        Map<String, Object> response = new HashMap<>();
        response.put("id", product.getId());
        response.put("name", product.getName());
        response.put("description", product.getDescription());
        response.put("price", product.getPrice());
        response.put("imageUrl", product.getImageUrl());
        response.put("category", product.getCategory());

        try {
            var inventory = inventoryService.getStock(id);
            response.put("stock", inventory.getQuantity());
        } catch (Exception e) {
            response.put("stock", null);
        }

        return response;
    }

    @PostMapping("/products")
    public ResponseEntity<?> create(@RequestBody Map<String, Object> body) {
        try {
            Product product = buildProductFromBody(body);
            Product saved = catalogService.saveProduct(product);

            // Auto-create inventory entry if stock provided
            Object stockVal = body.get("stock");
            if (stockVal != null) {
                int stock = Integer.parseInt(stockVal.toString());
                try {
                    inventoryService.addStock(saved.getId(), stock);
                } catch (Exception e) {
                    inventoryService.updateStock(saved.getId(), stock);
                }
            }

            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        try {
            Product product = buildProductFromBody(body);
            Product updated = catalogService.updateProduct(id, product);

            // Update inventory stock if provided
            Object stockVal = body.get("stock");
            if (stockVal != null) {
                int stock = Integer.parseInt(stockVal.toString());
                inventoryService.updateStock(id, stock);
            }

            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @DeleteMapping("/products/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            catalogService.deleteProduct(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Product deleted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/reviews")
    public Review saveReview(@RequestBody Review r) {
        return catalogService.addReview(r);
    }

    @GetMapping("/products/{id}/reviews")
    public List<Review> getReviews(@PathVariable Long id) {
        return catalogService.getReviews(id);
    }

    // Build a Product from the raw JSON map sent by the frontend
    private Product buildProductFromBody(Map<String, Object> body) {
        Product product = new Product();
        if (body.get("name") != null)
            product.setName(body.get("name").toString());
        if (body.get("description") != null)
            product.setDescription(body.get("description").toString());
        if (body.get("price") != null)
            product.setPrice(Double.parseDouble(body.get("price").toString()));
        if (body.get("imageUrl") != null)
            product.setImageUrl(body.get("imageUrl").toString());

        // Accept categoryId as a flat field (what the frontend sends)
        Object catId = body.get("categoryId");
        if (catId != null) {
            com.e_commerce.e_commerce.catalog.entity.Category cat =
                    new com.e_commerce.e_commerce.catalog.entity.Category();
            cat.setId(Long.parseLong(catId.toString()));
            product.setCategory(cat);
        }

        return product;
    }
}