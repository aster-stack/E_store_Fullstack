package com.e_commerce.e_commerce.inventory.controller;
import com.e_commerce.e_commerce.inventory.entity.inventory;
import com.e_commerce.e_commerce.inventory.service.InventoryService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {
    private final InventoryService inventoryService;
    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }
    @GetMapping("/{productId}")
    public inventory getStock(@PathVariable Long productId) {
        return inventoryService.getStock(productId);
    }
    @PostMapping("/add")
    public inventory addStock(@RequestParam Long productId,
                              @RequestParam int quantity) {
        return inventoryService.addStock(productId, quantity);
    }
    @PutMapping("/update")
    public inventory updateStock(@RequestParam Long productId,
                                 @RequestParam int quantity) {
        return inventoryService.updateStock(productId, quantity);
    }
}