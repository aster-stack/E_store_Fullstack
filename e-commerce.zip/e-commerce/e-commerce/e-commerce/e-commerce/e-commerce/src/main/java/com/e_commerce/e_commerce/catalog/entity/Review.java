package com.e_commerce.e_commerce.catalog.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "reviews")
@Data
public class Review {
    @Id
    private String id;
    private Long productId;
    private String username;
    private String comment;
    private int rating;
    private LocalDateTime createdAt = LocalDateTime.now();
}