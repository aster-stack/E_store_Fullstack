package com.e_commerce.e_commerce.catalog.repository;

import com.e_commerce.e_commerce.catalog.entity.Review;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ReviewRepository extends MongoRepository<Review, String> {
    List<Review> findByProductId(Long productId);
}