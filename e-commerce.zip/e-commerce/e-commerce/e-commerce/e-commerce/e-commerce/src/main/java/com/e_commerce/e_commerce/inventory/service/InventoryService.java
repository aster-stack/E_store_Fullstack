package com.e_commerce.e_commerce.inventory.service;
import com.e_commerce.e_commerce.inventory.entity.inventory;
import com.e_commerce.e_commerce.inventory.repository.InventoryRepository;
import org.springframework.stereotype.Service;
@Service
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    public InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }
    public inventory getStock(Long productId) {
        return inventoryRepository.findByProductId(productId)
                .orElseThrow(() -> new RuntimeException("Stock not found"));
    }

    public inventory addStock(Long productId, int quantity) {
        if (inventoryRepository.findByProductId(productId).isPresent()) {
            throw new RuntimeException("Stock already exists");
        }
        inventory inventory = new inventory();
        inventory.setProductId(productId);
        inventory.setQuantity(quantity);
        return inventoryRepository.save(inventory);
    }
    public inventory updateStock(Long productId, int quantity) {
        inventory inventory = getStock(productId);
        inventory.setQuantity(quantity);
        return inventoryRepository.save(inventory);
    }
    public void reduceStock(Long productId, int quantity) {
        inventory inventory = getStock(productId);
        if (inventory.getQuantity() < quantity) {
            throw new RuntimeException("Not enough stock");
        }
        inventory.setQuantity(inventory.getQuantity() - quantity);
        inventoryRepository.save(inventory);
    }
    public boolean isAvailable(Long productId, int quantity) {
        inventory inventory = getStock(productId);
        return inventory.getQuantity() >= quantity;
    }
}
