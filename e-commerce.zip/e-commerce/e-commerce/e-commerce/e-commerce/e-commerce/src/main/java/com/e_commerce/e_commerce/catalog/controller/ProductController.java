package com.e_commerce.e_commerce.catalog.controller;

import com.e_commerce.e_commerce.catalog.entity.*;
import com.e_commerce.e_commerce.catalog.service.CatalogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/catalog")
@CrossOrigin("*")
@RequiredArgsConstructor
public class ProductController {
    private final CatalogService catalogService;

    @GetMapping("/products")
    public List<Product> list() {
        return catalogService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public Product details(@PathVariable Long id) {
        return catalogService.getProductById(id);
    }

    @PostMapping("/reviews")
    public Review saveReview(@RequestBody Review r) {
        return catalogService.addReview(r);
    }

    @GetMapping("/products/{id}/reviews")
    public List<Review> getReviews(@PathVariable Long id) {
        return catalogService.getReviews(id);
    }
}