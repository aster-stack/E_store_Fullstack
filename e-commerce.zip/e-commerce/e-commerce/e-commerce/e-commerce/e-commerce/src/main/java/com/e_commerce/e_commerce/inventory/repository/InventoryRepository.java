package com.e_commerce.e_commerce.inventory.repository;
import com.e_commerce.e_commerce.inventory.entity.inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface InventoryRepository extends JpaRepository<inventory, Long> {

    Optional<inventory> findByProductId(Long productId);

}
