package com.e_commerce.e_commerce.catalog.service;

import com.e_commerce.e_commerce.catalog.entity.*;
import com.e_commerce.e_commerce.catalog.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CatalogService {
    private final ProductRepository productRepository;
    private final ReviewRepository reviewRepository;
    public List<Product> getAllProducts() { return productRepository.findAll(); }
    public Product getProductById(Long id) { return productRepository.findById(id).orElse(null); }
    public Review addReview(Review r) { return reviewRepository.save(r); }
    public List<Review> getReviews(Long pId) { return reviewRepository.findByProductId(pId); }
}