package com.e_commerce.e_commerce.catalog.repository;
import com.e_commerce.e_commerce.catalog.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
